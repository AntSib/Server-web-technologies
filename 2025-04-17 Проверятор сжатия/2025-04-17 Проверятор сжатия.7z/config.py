class Configuration(object):
    DEBUG:         bool = True
    host:           str = 'localhost'  # on host usage only
    port:           int = 8080
