from app import app
import view


if __name__ == '__main__':
    app.run()
